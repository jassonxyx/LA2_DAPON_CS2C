let uno = 25;
let two = 20;
let tres = 12;
let four = "15";
const five = 15;
console.log(uno + two + tres + four + five);

console.log(four > five);
console.log(four < five);
console.log(four >= five);
console.log(four <= five);
console.log(four === five);

let fur = 25;
let bar = 20;
let bus = 12;
let zip = "15";
const zap = 15;
console.log(fur - bar - bus - zip - zap);
let count = (fur * bus / zap);
console.log(count);
count = 20;