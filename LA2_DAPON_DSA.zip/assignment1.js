let given = "Felix Garcia Gabriel ";
let bdate = "April 11, 2005 ";
let bplace = "City of Candon Hospital, Candon City,Philippines 2710";
let destine = "Tablac,Candon City,Philippines 2710 ";
let course = "bachelor of science and computer science ";
let dream = "Game Developer ";
let high = given.toUpperCase();
let low = given.toLowerCase();

let mail = high + "was born " + bdate + "at " + bplace + ", and currently living at " + destine + ", " + low + "is taking up " + course + "and dreams to be " + dream + "after graduation";
console.log(mail);

let gName = "Trisha Mae Alonzo Gamata ";
let bdate1 = "September 21, 2004 ";
let bplace1 = "City of Candon Hospital, Candon City,Philippines 2710";
let destine1 = "Tablac,Candon City,Philippines 2710 ";
let course1 = "bachelor of science and computer science ";
let dream1 = "Game Developer ";
let high1 = gName.toUpperCase();
let low1 = gName.toLowerCase();

let info = high1 + "was born " + bdate1 + "at " + bplace1 + ", and currently living at " + destine1 + ", " + low1 + "is taking up " + course1 + "and dreams to be " + dream1 + "after graduation";
console.log(info);

let clas = "Gabriel Ricarde Molina ";
let bdate2 = "April 11, 2005 ";
let bplace2 = "City of Candon Hospital, Candon City,Philippines 2710";
let from = "San Isidro,Candon City,Philippines 2710 ";
let course2 = "bachelor of science and computer science ";
let dream2 = "Game Developer ";
let up = clas.toUpperCase();
let down = clas.toLowerCase();

let infos = up + "was born " + bdate2 + "at " + bplace + ", and currently living at " + from + ", " + down + "is taking up " + course + "and dreams to be " + dream + "after graduation";
console.log(infos);